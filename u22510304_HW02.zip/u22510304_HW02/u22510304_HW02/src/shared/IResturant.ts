// restaurant.interface.ts

export interface IRestaurant {
    id: number;
    name: string;
    cuisine: string;
    rating: number;
    distance: string;
    price: number;
    image: string;
  }
  