// IOrder.ts

import { IRestaurant } from "./IResturant";

export interface IOrder {
  id: string; // Unique identifier for the order
  restaurant: IRestaurant;
  items: string[]; 
}
