// cart.service.ts

import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { IRestaurant } from 'src/shared/IResturant';
import { IOrder } from 'src/shared/ICart';
import { v4 as uuidv4 } from 'uuid'; // Import uuidv4 function from uuid package
@Injectable({
  providedIn: 'root'
})
export class CartService {
  
  private orders: IOrder[] = [];
  private ordersSubject: BehaviorSubject<IOrder[]> = new BehaviorSubject<IOrder[]>([]);
  private previousOrderSubject: BehaviorSubject<IOrder | null> = new BehaviorSubject<IOrder | null>(null);
  constructor() { }

  getOrders(): Observable<IOrder[]> {
    return this.ordersSubject.asObservable();
  }

  addOrder(restaurant: IRestaurant) {
    // Clear existing orders
    this.clearCart();
    
    // Add the new order
    const order: IOrder = {
      id: uuidv4(), // Generate a unique id for the order
      restaurant,
      items: [] // You can add items to the order if needed
    };
    this.orders.push(order);
    this.ordersSubject.next(this.orders);
  }
  

  clearCart() {
    this.orders = [];
    this.ordersSubject.next(this.orders);
  }
  // Add other methods for managing orders as needed

  setPreviousOrder(order: IOrder) {
    this.previousOrderSubject.next(order);
  }

  getPreviousOrder() {
    return this.previousOrderSubject.asObservable();
  }

}
