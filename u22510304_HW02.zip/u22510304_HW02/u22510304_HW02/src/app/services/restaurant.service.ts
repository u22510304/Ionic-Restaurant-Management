// restaurant.service.ts

import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IRestaurant } from 'src/shared/IResturant';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  private selectedRestaurant: IRestaurant | null = null;
  private restaurants: IRestaurant[] = [
    // Define your restaurants here
    {
      id: 1,
      name: "Jollof of Africa",
      cuisine: "African Cuisine",
      rating: 5,
      distance: "2.59 kms away",
      price: 100,
      image: "assets/jollof1.jpeg"
    },
    {
      id: 2,
      name: "Ayoba Cafe Shisanyama",
      cuisine: "African Cuisine",
      rating: 4.4,
      distance: "1.83 kms away",
      price: 120,
      image: "assets/Shisayanma.jpg"
    },
    {
      id: 3,
      name: "Spice-The Indian Kitchen",
      cuisine: "Asian Cuisine",
      rating: 4.1,
      distance: "0.9 km away",
      price: 80,
      image: "assets/Briyani.jpeg"
    },
    {
      id: 4,
      name: "Kung Fu Kitchen",
      cuisine: "East Asian Cuisine",
      rating: 5,
      distance: "3 km away",
      price: 120,
      image: "assets/Chinese.jpg"
    }
    
  ];

  constructor() { }

  getRestaurants(): Observable<IRestaurant[]> {
    return of(this.restaurants);
  }

  getRestaurantById(id: number): Observable<IRestaurant | undefined> {
    return of(this.restaurants.find(restaurant => restaurant.id === id));
  }

  setSelectedRestaurant(restaurant: IRestaurant) {
    this.selectedRestaurant = restaurant;
  }

  getSelectedRestaurant(): IRestaurant | null {
    return this.selectedRestaurant;
  }

  clearSelectedRestaurant() {
    this.selectedRestaurant = null;
  }
}


