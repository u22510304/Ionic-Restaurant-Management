import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { HelpModalComponent } from 'src/app/Modals/help-modal/help-modal.component';
import { Router, NavigationEnd  } from '@angular/router';
import { Customer } from 'src/shared/customer';
import { IOrder } from 'src/shared/ICart'; // Import the IOrder interface
import { CartService } from 'src/app/services/cart.service';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
})
export class AccountComponent implements OnInit {
  customer: Customer;
  editing: boolean = false;
  originalCustomer: Customer;
  orders: IOrder[]; // Assuming you have an array of orders for the customer
  currentOrder: IOrder | null = null;
  previousOrder: IOrder | null = null;
  constructor(public dialog: MatDialog, private router: Router, private cartService: CartService, private cdr: ChangeDetectorRef) {
    // Initialize customer with hardcoded values
    this.customer = new Customer('John Doe', 'john.doe@example.com', '123 Main St');
    this.originalCustomer = { ...this.customer };
    this.orders = []; // Initialize orders array

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd && event.url === '/tabs/account') {
        this.ngOnInit();
      }
    });
    
     
    
  }

  



  ngOnInit() {
    console.log('ngOnInit() called in AccountComponent');
    const previousOrderString: string | null = localStorage.getItem('previousOrder');
    console.log('Previous order string from localStorage:', previousOrderString);
    if (previousOrderString) {
      this.previousOrder = JSON.parse(previousOrderString);
      console.log('Previous order parsed from localStorage:', this.previousOrder);
    }
  }
  
  
    
  
  

  openHelpModal(): void {
    this.dialog.open(HelpModalComponent, {
      width: '250px',
      position: {left: '50px'}
      
      
    });
  }

  reorder() {
    console.log('Reordering previous order:', this.previousOrder);
    if (this.previousOrder) {
      this.cartService.clearCart();
      this.cartService.addOrder(this.previousOrder.restaurant);
      console.log('Previous order added to cart:', this.previousOrder.restaurant);
      this.router.navigate(['tabs', 'cart']);
      // this.cdr.detectChanges(); // Manually trigger change detection (remove this line if not necessary)
    }
  }
  
  
  
  
  editAccountDetails(): void {
    this.editing = true;
  }
  
  
  saveAccountDetails(): void {
    // Implement logic to save the edited account details
    this.editing = false;
    this.originalCustomer = { ...this.customer };
  }
  
  cancelEdit(): void {
    this.editing = false;
    // Reset customer details to the original values
    this.customer = { ...this.originalCustomer };
  }
}  
