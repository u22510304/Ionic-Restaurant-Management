// home.page.ts

import { Component, OnInit } from '@angular/core';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { IRestaurant } from 'src/shared/IResturant';
import { CartService } from 'src/app/services/cart.service';
import { IonicSlides } from '@ionic/angular';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  restaurants: IRestaurant[] = [];
  swiperModules = [IonicSlides];
  constructor(private restaurantService: RestaurantService, private cartService: CartService) { }
  ngOnInit() {
    this.restaurantService.getRestaurants().subscribe(restaurants => {
      this.restaurants = restaurants;
    });
  }

  onRestaurantClick(restaurant: IRestaurant) {
    this.cartService.addOrder(restaurant);
  }

}
