import { Component, OnInit } from '@angular/core';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { IRestaurant } from 'src/shared/IResturant';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {

  restaurants: IRestaurant[] = [];
  filteredRestaurants: IRestaurant[] = [];

  constructor(private restaurantService: RestaurantService, private cartService: CartService) { }

  ngOnInit() {
    this.restaurantService.getRestaurants().subscribe(restaurants => {
      this.restaurants = restaurants;
      this.filteredRestaurants = [...restaurants];
    });
  }
  search(query: string | null | undefined) {
    if (query != null) {
      this.filteredRestaurants = this.restaurants.filter(restaurant =>
        restaurant.name.toLowerCase().includes(query.toLowerCase()
      
      )
        
      );
      console.log('Filtered Restaurants:', this.filteredRestaurants);
    }
  }
  
  

  onRestaurantClick(restaurant: IRestaurant) {
    this.cartService.addOrder(restaurant);
  }

}
