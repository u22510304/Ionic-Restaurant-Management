// cart.page.ts

import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { IOrder } from 'src/shared/ICart';
import { ModalController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { IRestaurant } from 'src/shared/IResturant';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';




@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage implements OnInit {
  orders: IOrder[] = [];
  previousOrder: IOrder | null = null;
  deliveryFee: number = 50;
  total: number = 0;
  deliveryInstructions: string = '';
  private ordersSubject: BehaviorSubject<IOrder[]> = new BehaviorSubject<IOrder[]>([]);

  constructor(private cartService: CartService, private modalController: ModalController, private alertController: AlertController, private router: Router, private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    this.cartService.getOrders().subscribe(orders => {
      this.orders = orders;
      this.calculateTotal();
    });
  }


  generateId(): string {
    // Generate a random ID
    return Math.random().toString(36).substr(2, 9);
  }


  addOrder(restaurant: IRestaurant) {
    // Clear existing orders
    this.clearCart();
    
    // Add the new order
    const id = this.generateId();
    const order: IOrder = {
      id,
      restaurant,
      items: [] // You can add items to the order if needed
    };
    this.orders.push(order);
    this.ordersSubject.next(this.orders);
    localStorage.setItem('previousOrder', JSON.stringify(order));
  }
  
  
  
  


  calculateTotal() {
    let totalPrice = this.orders.reduce((acc, order) => acc + order.restaurant.price, 0);
    this.total = totalPrice + this.deliveryFee;
  }

  async presentSuccessAlert() {
    const alert = await this.alertController.create({
      header: 'Payment Successful',
      message: 'Thank you for your order!',
      buttons: ['OK']
    });
    await alert.present();
  }

  clearCart() {
    this.orders = [];
    this.ordersSubject.next(this.orders);
    this.total = 0;
  }
  

  
  makePayment() {
    if (this.orders.length > 0) {
      localStorage.setItem('previousOrder', JSON.stringify(this.orders[0]));
      console.log('Previous order updated in localStorage:', this.orders[0]);
      this.router.navigate(['tabs', 'account']);
      this.presentSuccessAlert();
      this.clearCart();
  
      // Manually trigger change detection in the account page
      console.log('Detecting changes...');
      this.cdr.detectChanges();
      console.log('Changes detected.');
    }
  }
  
  
  
  
 
  

}
